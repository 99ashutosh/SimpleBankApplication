#include <gtk/gtk.h>

int main(int argc, char *argv[]) {

  

  gtk_main();

  return 0;
}
